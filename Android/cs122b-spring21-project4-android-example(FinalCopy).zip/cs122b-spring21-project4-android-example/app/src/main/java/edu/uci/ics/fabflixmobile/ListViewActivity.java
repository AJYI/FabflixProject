package edu.uci.ics.fabflixmobile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ListViewActivity extends Activity {
    /*
    In Android, localhost is the address of the device or the emulator.
    To connect to your machine, you need to use the below IP address
    */
    private final String host = "fablix.club";
    private final String port = "8080";
    private final String domain = "cs122b-spring21-project1";
    private final String baseURL = "http://" + host + ":" + port + "/" + domain;


    private String query;
    private Button previousButton;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);

        // Gets the query
        Intent intent = getIntent();
        String data = intent.getStringExtra("query");
        query = data;

        // This is the code to get the actual page number.
        String pageNumber = intent.getStringExtra("pageNumber");
        int intPageNumber;
        if (pageNumber == null){
            intPageNumber = 1;
        }
        else{
            intPageNumber = Integer.parseInt(pageNumber);
        }

        previousButton = findViewById(R.id.previousButton);
        nextButton = findViewById(R.id.nextButton);

        // Assigning some listeners
        nextButton.setOnClickListener(view -> nextBttn(data, intPageNumber));
        previousButton.setOnClickListener(view->previousBttn(data, intPageNumber));


        System.out.println(query);

        // This is the what we will keep our movie list data in
        final ArrayList<Movie> movieList = new ArrayList<>();

        // Generating the JSONObject from the servlet call
        final RequestQueue queue = NetworkManager.sharedManager(this).queue;
        final StringRequest loginRequest = new StringRequest(
                Request.Method.POST,
                baseURL + "/HomePageSearch/homePageSearchResultAndroid",
                response -> {
                    System.out.println(response);
                    try {
                        // SOURCE: https://stackoverflow.com/questions/9151619/how-to-iterate-over-a-jsonobject
                        // To iterate over json object
                        JSONArray objArr = new JSONArray(response);

                        // We are iterating over the JSON ARRAY
                        for(int i = 0; i < objArr.length(); i++){
                            // We are turning the objects inside teh array[i] into objects
                            System.out.println("Check");
                            JSONObject obj = objArr.getJSONObject(i);
                            // We get the keys within the objects
                            Iterator<String> keys = obj.keys();

                            String movieID = null;
                            String title = null;
                            String year = null;
                            String director = null;
                            String genres = null;
                            String stars = null;

                            System.out.println("Check2");

                            while(keys.hasNext()){
                                // Now we are iterating over the json array
                                String keyName = keys.next();
                                if (keyName.equals("movie_id")){
                                    movieID = (String)obj.get(keyName);
                                }
                                else if(keyName.equals("movie_title")){
                                    title = (String)obj.get(keyName);
                                }
                                else if(keyName.equals("movie_year")){
                                    year = (String)obj.get(keyName);
                                }
                                else if(keyName.equals("movie_director")){
                                    director = (String)obj.get(keyName);
                                }
                                else if(keyName.equals("movie_genre")){
                                    genres = (String)obj.get(keyName);
                                }
                                else if(keyName.equals("movie_actors")){
                                    stars = (String)obj.get(keyName);
                                }
                            }
                            Movie movieObj = new Movie(movieID, title, year, director, genres, stars);
                            movieList.add(movieObj);
                        }
                        System.out.println("out here");
                        // Gotta do some iterations
                        doAdapter(movieList);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    // error
                    Log.d("login.error", error.toString());
                }) {
            @Override
            protected Map<String, String> getParams() {
                // POST request form data
                final Map<String, String> params = new HashMap<>();
                params.put("movieTitle", query); // We insert the query in here
                params.put("pageNumber", String.valueOf(intPageNumber));
                return params;
            }
        };

        // important: queue.add is where the login request is actually sent
        queue.add(loginRequest);
    }

    void doAdapter(ArrayList<Movie> movieList){
        MovieListViewAdapter adapter = new MovieListViewAdapter(movieList, this);

        ListView listView = findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Movie movie = movieList.get(position);
            Intent intent = new Intent(ListViewActivity.this, SingleMovie.class);
            intent.putExtra("movieID", movie.getMovieID());
            startActivity(intent);
        });
    }

    public void nextBttn(String data, int intPageNumber){

        Intent intent = new Intent(ListViewActivity.this, ListViewActivity.class);
        intent.putExtra("query", data);
        intent.putExtra("pageNumber", String.valueOf(intPageNumber + 1));
        startActivity(intent);
    }

    public void previousBttn(String data, int intPageNumber){
        if(intPageNumber == 1){
            return;
        }
        Intent intent = new Intent(ListViewActivity.this, ListViewActivity.class);
        intent.putExtra("query", data);
        intent.putExtra("pageNumber", String.valueOf(intPageNumber - 1));
        startActivity(intent);
    }
}