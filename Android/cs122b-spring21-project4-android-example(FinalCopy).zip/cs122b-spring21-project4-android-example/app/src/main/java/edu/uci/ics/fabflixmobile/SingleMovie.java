package edu.uci.ics.fabflixmobile;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SingleMovie extends ActionBarActivity {

    private Button backButton;
    private TextView movieTitle;
    private TextView movieYear;
    private TextView director;
    private TextView stars;
    private TextView genres;

    /*
      In Android, localhost is the address of the device or the emulator.
      To connect to your machine, you need to use the below IP address
     */
    private final String host = "fablix.club";
    private final String port = "8080";
    private final String domain = "cs122b-spring21-project1";
    private final String baseURL = "http://" + host + ":" + port + "/" + domain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // upon creation, inflate and initialize the layout
        setContentView(R.layout.single_movie);
        movieTitle = findViewById(R.id.movieTitle);
        movieYear = findViewById(R.id.movieYear);
        director = findViewById(R.id.director);
        stars = findViewById(R.id.stars);
        genres = findViewById(R.id.genres);
        // Gets the movieID
        Intent intent = getIntent();
        String data = intent.getStringExtra("movieID");
        System.out.println(data);

        // Generating the JSONObject from the servlet call
        final RequestQueue queue = NetworkManager.sharedManager(this).queue;
        final StringRequest singleMovieRequest = new StringRequest(
                Request.Method.POST,
                baseURL + "/MovieInformation/movieAndroid",
                response -> {
                    try {
                        // SOURCE: https://stackoverflow.com/questions/9151619/how-to-iterate-over-a-jsonobject
                        // To iterate over json object
                        JSONArray objArr = new JSONArray(response);
                        System.out.println(response);
                        // We are iterating over the JSON ARRAY
                        for(int i = 0; i < objArr.length(); i++){
                            // We are turning the objects inside teh array[i] into objects
                            JSONObject obj = objArr.getJSONObject(i);
                            // We get the keys within the objects
                            Iterator<String> keys = obj.keys();


                            while(keys.hasNext()){
                                // Now we are iterating over the json array
                                String keyName = keys.next();
                                if (keyName.equals("movie_title")){
                                    movieTitle.setText((String)obj.get(keyName));
                                }
                                else if(keyName.equals(("movie_year"))){
                                    movieYear.setText((String)obj.get(keyName));
                                }
                                else if(keyName.equals("movie_director")){
                                    director.setText((String)obj.get(keyName));
                                }
                                else if(keyName.equals("movie_actors")){
                                    stars.setText((String)obj.get(keyName));
                                }
                                else if(keyName.equals("movie_genres")){
                                    genres.setText((String)obj.get(keyName));
                                }
                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    // error
                    Log.d("login.error", error.toString());
                }) {
            @Override
            protected Map<String, String> getParams() {
                // POST request form data
                final Map<String, String> params = new HashMap<>();
                params.put("movieID", data); // We insert the query in here
                return params;
            }
        };

        // important: queue.add is where the login request is actually sent
        queue.add(singleMovieRequest);



    }

}