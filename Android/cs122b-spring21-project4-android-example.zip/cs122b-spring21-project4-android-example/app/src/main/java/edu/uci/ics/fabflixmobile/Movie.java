package edu.uci.ics.fabflixmobile;

public class Movie {
    private final String movieID;
    private final String title;
    private final String year;
    private final String director;
    private final String genres;
    private final String stars;

    public Movie(String movieID, String title, String year, String director, String genres, String stars) {
        this.movieID = movieID;
        this.title = title;
        this.year = year;
        this.director = director;
        this.genres = genres;
        this.stars = stars;
    }

    public String getMovieID() { return movieID;}

    public String getTitle() {
        return title;
    }

    public String getYear() {
        return year;
    }

    public String getDirector(){ return director;}

    public String getGenres(){ return genres;}

    public String getStars() {return stars;}
}